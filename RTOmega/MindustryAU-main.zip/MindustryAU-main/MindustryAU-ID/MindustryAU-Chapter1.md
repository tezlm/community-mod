***Mindustry AU*** - Kisah 2

Bagian 1 - Tanah longsor

Itu adalah hari yang damai, Crux hampir sepenuhnya mengendalikan Serpulo.

Kemudian, sebuah benda kecil jatuh...

"Apa itu tadi? Meteor mungkin?” Tanya Komandan Crux atas.

“Kami tidak tahu, itu terlalu cepat untuk radar kami.” kata Laksamana.

"Kirim pasukan kecil ke Ground Zero dan periksa apa itu." kata Komandan.

-Sedikit yang mereka tahu, itu adalah inti dari Sharded.

Beberapa hari berlalu, lalu Panglima bertanya, “Benda apa yang jatuh itu?”

"Yah ..." kata Laksamana.

"Tidak ada satu pun dari unit kami yang kembali, mereka mungkin semua terbunuh atau ditangkap." kata Laksamana.

...

Seminggu berlalu, lalu sebuah objek diluncurkan dari Ground Zero ke Frozen Forest.

"Apa yang terjadi?" tanya Komandan.

Laksamana menjawab, "Sebuah objek tak dikenal diluncurkan dari Ground Zero ke hutan Beku Pak."

Komandan berhenti beberapa saat dan kemudian menyadari, “ITU BUKAN OBJEK! ITULAH INTI!”

Laksamana berteriak panik: “Tapi itu tidak mungkin!

Tidak ada peradaban lain yang dikenal yang bisa membuat inti!”

“Kami tahu satu sekarang! Catat sebagai S, dengan warna kuning, di arsip Kapten. Beri nama Shard!”

"Tapi Pak" kata Laksamana, "Shard adalah jenis inti yang kita miliki."

“Kalau begitu buat Shard-ed”, teriak Komandan dan menatap ke jendela.

-Telah dimulai...
