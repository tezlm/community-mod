# MindustryAU
A FanFic/Lore about Mindustry Campaign, from the perspective of Crux.

This FanFic/Lore is writen and edited by **RTOmega.** and Automaticaly translated in Indonesan

# Contributors:
-
-
-
