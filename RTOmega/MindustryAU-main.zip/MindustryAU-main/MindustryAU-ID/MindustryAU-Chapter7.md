**Bagian 7 – Gagal sekali lagi!**

"Mari kita uji ini, *Sharded*" kata Komandan Atas.

"Kirim T4 ke pertumbuhan berlebih dan lihat apakah itu akan gagal" tambahnya.

"Ya pak!" jawab Laksamana.

…

"T4 gagal, kita perlahan-lahan dihancurkan!" kata Kapten.

Komandan Tinggi berpikir dalam-dalam.

“Kami akan menghentikan mereka di NPC.” Dia berkata.

"Tapi bagaimana caranya?" tanya Laksamana.

"Aku akan pergi ke sana dengan kapalku." Dia menambahkan.

"Siapkan Eclipse saya!" dia berteriak dan meninggalkan ruang komando.

Laksamana tidak tahu jenis kapal apa *Eclipse* itu.

Dia dengan cepat mengikuti Komandan Atas.

Dia menunggu di luar, tidak ada apa-apa. Itu hanya gurun terbuka.

Kemudian bayangan menghalangi matahari. Itu semakin besar dan besar setiap saat.

Laksamana terkejut, itu ada di depannya. Penghancur Giga. Itu adalah Kapal Bintang terbesar yang pernah dilihatnya. Dikemas dengan Cruiser menghancurkan laser dan meriam super besar. Dia terdiam saat melihat Komandan Tinggi berjalan ke lift. Dia berdiri di sana sementara Penghancur Bintang terbang ke cakrawala.

…
