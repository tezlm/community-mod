**Bagian 9 – Hanya masalah Waktu**

Laksamana bergegas melewati koridor "Jalankan Protokol Darurat 01-49!" dia berteriak ke comms.

Alarm mulai berbunyi, semua orang panik.

“Evakuasi ke Terminal Peluncuran Planet! Saya ulangi Evakuasi ke Planetary Launch Terminal!” dia mulai berteriak melalui komunikasi.

"Tuan, Impact 0078 turun!" lapor Kapten.

“Satu Pasukan, lindungi PLT! Pasukan B, coba pegang Sharded sebanyak mungkin di Desolate Rift!” teriak Laksamana.

“Kita perlu waktu untuk mengungsi!” tambahnya dan bergegas menuju kapal pengangkut terakhir menuju PLR.

…

Tak kalah ricuh di PLT, semua orang berlarian dan berharap aman di sana.

"Cobalah untuk melindungi dengan semua kekuatanmu!" teriak Laksamana.

“Pasukan kita gagal di Desolate Rift” kata Komandan.

“Serang dengan Zenith!” teriak Laksamana.

"Eh, ya, tentang itu ..." mulai Komandan.

“…”

“Mereka sudah menghancurkannya…” lanjutnya sambil menggaruk kepalanya.

"Tembak dengan Spectre !?" tanya Laksamana.

"Ya, mereka, mereka juga membunuh mereka." lanjut Komandan.

"Saya tidak berpikir saya akan melakukan ini ... Lepaskan Pemerintahan!" teriak Laksamana.

"Dan Anda tidak akan pernah melakukannya karena itu adalah hal pertama yang mereka hancurkan." Kata Komandan.

“Apakah saya harus melakukan semua yang dia-“, kata Laksamana. Tanah mulai bergetar.

Laksamana bergegas keluar dan melihat ke langit, Inti Nukleus jatuh dari langit, siap mendarat.

"Mereka disini." gumam Laksamana.

…

"Toksopida, bersiaplah." Kata Komandan.

“Serangan dalam 5,4,3,2,1. Menyerang!" dia berteriak.

-Satu per satu, semua unit Crux dihancurkan oleh kehancuran, hantu, dan bayangan. Crux kehilangan banyak menara dan unit tetapi gagal menghentikan Sharded.

“INTI DI BAWAH SERANGAN! INTI DI BAWAH SERANGAN!” teriak Komandan.

Laksamana tahu satu-satunya cara adalah melarikan diri, dia dengan cepat bergegas ke InterPlanetary Accelerator,

Menghancurkan tombol peluncuran dan melompat ke dalam.

Pintu tertutup, dia mendengar inti meledak, sudah terlambat untuk semua orang ...

…

Akselerator mulai menghitung,

“Peluncuran dalam 10, 9”

Akselerator mulai menerima kerusakan.

“8, 7, 6, 5, 4”

Laksamana panik dalam tingkat yang gila.

“3, 2, 1, KEBAKARAN”

Akselerator meluncurkan pod di luar angkasa lebih cepat daripada suara, seluruh Serpulo bergetar dengan kekuatannya, Admiral ambruk ke lantai dan pod berhasil merapat ke Crux InterGalactic Space Station.

Pintu terbuka dan Laksamana berdiri.

Dia berjalan ke ruang komando, perlahan.

…

“Kami kehilangan Serpulo” katanya.

Kaisar tersenyum.

"Ini harga kecil yang harus dibayar untuk intel ini." Kata Kaisar.

"Sekarang kita tahu bahwa ada orang lain." Dia melanjutkan.

"Ini, ambil T6 ini dan kembali ke Tantros." Dia menambahkan, sambil menunjuk salah satu dari banyak Destroyer di armada luar angkasa.

"Baik tuan ku." Kata Laksamana dan meninggalkan ruangan.

"Pertempuran ini baru saja dimulai." Kata Kaisar.

…

**Mindustry AU oleh RTOmega**

*Tolong beri umpan balik dan beri tahu jika saya membuat kesalahan*
Anda dapat berkontribusi dengan membuat pull request.
