**Bagian 4 – Pegunungan dan Pulau**

-Setelah beberapa kali mencoba, Crux masih terus gagal mengalahkan Sharded.

“Pak, sepertinya mereka telah meluncurkan ke 2 sektor secara bersamaan.” Kata Laksamana.

“Sektor apa?” tanya Komandan.

"Pegunungan Bernoda dan Kepulauan Windswept Pak." Kata Laksamana.

"Ini menjadi masalah yang lebih besar setiap hari, kirim unit terbaik kami!" kata Komandan.

“Lihatlah, unit baru dan kuat kita: Angkatan Laut” kata profesor saat memasuki ruang pusat komando.

“Unit-unit baru ini memiliki rudal yang kuat dan berenang di air.” Lanjut profesor.

Kapten memasuki ruangan dan mulai berbicara, "Tuan, mekanik kami membangun unit yang akan menyelesaikan masalah kami di Pegunungan Stained!"

"Apa itu?" tanya profesor.

“Ini satu-satunya, *Scepter*, ini adalah stasiun pertempuran berjalan, 50 kali lebih kuat dari Fortress. Penuh dengan blaster raksasa dan 2 meriam mega, unit ini dapat menghancurkan apa pun di jalannya.”

“Aku tidak ingin ada kegagalan kali ini! Kita harus memenangkan perang ini, sebelum terlambat.” Kata Komandan.

…

“Mereka telah mengalahkan sebagian besar unit angkatan laut kita” kata kapten.

“Aku tahu mereka akan melakukannya! Untuk beberapa alasan, semua unit Anda adalah profesor yang tidak berguna! ” teriak Komandan.

Profesor mengambil komunikasi, "Lepaskan angkatan laut yang lebih besar, saya ulangi, lepaskan angkatan laut yang lebih besar!"

Laksamana dan Komandan saling memandang.

"Profesor, kami akan membunuh inti mereka, tetapi kemudian seorang lancer membunuh angkatan laut terakhir kami!" teriak Kapten.

Profesor menghela nafas, dia tahu dia harus berbuat lebih baik.

…

"Apakah serangan mendadak kita sudah siap?" tanya Komandan.

"Ya pak!" jawab Kapten.

"Lepaskan *Scepter*!" memerintahkan Komandan.

"Kami menghancurkan lancer mereka, Tuan!" kata kapten.

"Ripple mereka menembak, tapi kita hampir mencapai inti mereka." Dia melanjutkan.

Komandan mulai ragu.

"5 pukulan" kata Kapten dan mulai menghitung.

“4, 3, 2, 1”…

Komunikasi terputus.

Laksamana memandang Komandan.

Mereka berdua tahu bahwa mereka gagal.

-Tapi itu hanya akan menjadi lebih buruk dari sini.
