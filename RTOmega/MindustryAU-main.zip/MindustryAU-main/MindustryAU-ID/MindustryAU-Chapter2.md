**Bagian 2 - Kekacauan di Kawah**

2 Minggu telah berlalu sejak penemuan Sharded.

Segalanya tampak tenang, lalu terjadi.

Inti lain diluncurkan. Namun, itu dari Hutan Beku.

Core mendarat di The Craters.

Komandan memberi perintah: "Temukan inti itu dan hancurkan!"

Kapten menjawab: "Kami mengirim salah satu unit terbaru dan terbaik kami, Zenith, sebuah kapal perang lengkap dan lapis baja dengan 2 peluncur roket."

Laksamana Melanjutkan: "Tidak ada kemungkinan mereka lolos kali ini." Kemudian dia tersenyum dan melihat ke kapal perang raksasa.

…

"Apakah kamu siap untuk menyerang Pilot?" tanya Kapten.

"Ya pak, semua sistem bersih, kami melihat markas musuh." Jawab Pilot.

Komandan tersenyum dan berkata: "Tembak di pencar, jika kita menghancurkan mereka, tidak ada kemungkinan mereka memenangkan pertempuran ini!"

Kemudian pilot menjawab: “Si- - - Ada masalah kecil- - -“

Kemudian komunikasi terputus.

Baik Komandan dan Laksamana saling memandang, kaget. Mereka menyadari bahwa ini adalah masalah yang lebih besar dari yang mereka bayangkan.

Ini bukan serangan kecil, itu adalah Invasi planet total!
