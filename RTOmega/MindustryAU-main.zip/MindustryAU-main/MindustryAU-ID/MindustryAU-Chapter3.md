**Bagian 3 – Shores UnderAtack**

"Tuan, kami telah mendeteksi peluncuran lain, kali ini di Kawah." Kata Laksamana.

"Di mana mereka meluncurkan?" tanya Komandan.

“Sepertinya mereka pergi ke Ruinous Shores.” Jawab Laksamana.

Komandan berpikir sejenak dan berkata: "Bagaimana jika kita menyerang dalam kelompok kecil tetapi lebih cepat?"

“Dengan begitu, kita bisa membunuh mereka dengan mudah.” Kata Kapten.

Kapten membuka komunikasi dan memberi perintah: “Serang dari udara dan darat! Targetkan inti dan kali ini, temukan jalan menuju pertahanan terlemah!”

"Ya pak!" Kata Komando. Mengangguk pilot.
…

Sebuah pesan datang dari Komando: "Pak, mereka memiliki lancer, saya tidak tahu berapa lama lagi kita bisa berdiri."

“Jangan khawatir Komando! Kami memiliki cadangan, kami mengirim yang baru, Benteng, itu adalah tangki berjalan lapis baja lengkap dengan hujan es yang dikemas. ”

…


![image](https://user-images.githubusercontent.com/62565267/120976373-f37e2480-c77a-11eb-8cd1-17e47a37a98e.png)

“Kami kehilangan sinyal, sektor ini tertangkap.” Kata Laksamana, dengan suara serak.

-Namun, yang tidak mereka ketahui adalah, ini baru permulaan...
