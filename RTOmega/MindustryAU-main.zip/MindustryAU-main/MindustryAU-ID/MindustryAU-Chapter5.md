**Bagian 5 - Panggilan untuk Bala Bantuan**

-Crux terus gagal menghentikan Sharded dan sekarang diserang olehnya.

Tanpa peluang untuk berhasil, mereka mencoba yang terbaik untuk melindungi markas mereka.

Sebuah pesan datang dari Kapten: "Taktik kami tidak cocok untuk serangan mereka!"

Laksamana menghela nafas dan menjawab: “Bagaimana mereka bisa mengalahkan kita? Mustahil! Aku memerintahkanmu untuk pergi dan menghentikan mereka di Salt Flats and Extraction Outpost!”

Kapten bahkan tidak menjawab. Dia tahu mereka akan gagal. Mereka membutuhkan senjata yang lebih baik, unit yang lebih besar.

Komandan tahu apa yang harus dia lakukan.

Dia berjalan ke komunikasi, sangat lambat, memasukkan kode dan mulai mengirim pesan.

“Tuanku…” katanya.

“Pasukan kami tidak efektif melawan Sharded.” Dia melanjutkan.

“Kami membutuhkan bala bantuan. Kita perlu—“ Dia berhenti selama beberapa detik.

"T5" tambahnya.

"Baiklah," kata Kaisar.

"Tapi saya tidak ingin ada kegagalan lagi atau Anda akan digantikan." dia menambahkan.

…
