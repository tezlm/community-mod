**Bagian 8 – Eclipse vs Forces of Sharded**

-Komandan Atas perlahan mendekati NPC.

Dia mendapat pesan dari Laksamana, "Mereka telah mengalahkan semua pasukan kita." Dia berkata.

"Kamu adalah satu-satunya harapan" tambahnya.

“Kami melihat NPC di cakrawala.” Kata Pilot.

"Siapkan kanon dan laser!" kata Panglima Tinggi.

"Serang dalam 3, 2, 1, tembak!" dia berteriak.

…

-Ledakan demi ledakan, Eclipse perlahan-lahan semakin dekat ke inti, tapi itu mengambil kerusakan berbahaya.

"Kami hampir mencapai inti mereka!" kata pilot.

"Tapi kita tidak tahu berapa lama kapal penjelajah kita bisa berdiri." Dia menambahkan.

"Kekuatan penuh untuk senjata!" Komandan atas memerintahkan.

"Tapi Pak, perisai kita hampir habis." kata Kapten.

"AKU MENGATAKAN SERANGAN!" dia memesan.

"Ya pak!" jawab Pilot.

-Mereka mencapai inti tetapi topan tidak menyerah.

"Ayo ayo!" kata Panglima Tinggi.

“Perisai ke bawah!” kata Pilot.

"Terus!" perintah Panglima Tinggi.

"Mesin mati, kita akan jatuh!" teriak Kapten.

"Terus menembak!" teriak Komandan Tinggi.

"KITA HARUS PERGI!" jawab Kapten.

"Tidak sampai kita menghancurkan inti ini!" kata Panglima Tinggi.

Kapten dan Pilot berlari ke pod pelarian. Mereka menekan tombol darurat dan melihat pintu tertutup saat Komandan Tinggi tetap di sana. Menonton.

Pod diluncurkan.

"Kita seharusnya menyelamatkan Komandan Atas!" kata Kapten.

"Sudah terlambat untuknya." Jawab Pilot dan melihat ke arah kapal perusak raksasa saat itu jatuh ke darat. Gagal sekali lagi…

…


![image](https://user-images.githubusercontent.com/62565267/120976922-756e4d80-c77b-11eb-8828-f6305c3c9fe8.png)
