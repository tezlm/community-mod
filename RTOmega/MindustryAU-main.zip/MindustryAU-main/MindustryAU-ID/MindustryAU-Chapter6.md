**Bagian 6 – Penerbitan Jamur**

-Fungal Pass kecil tapi itu adalah jalan menuju thorium dan itu adalah satu-satunya kesempatan Crux menghentikan Sharded untuk selamanya.

“Tuan, Sharded sedang berkembang. Sangat lucu bahwa mereka menggunakan busur dan duo melawan kami di Fungal Pass. ” Kata Laksamana.

Komandan menjawab, “Kirim mega, poly, mace, daggers, crawler, fortress! Apa pun yang kita miliki! Kita harus menghentikan mereka!”

…

"Kami sedang diserang!" kata Kapten.

“Satu inti turun dan kami gagal bertahan.” Dia menambahkan.

"Kami mengirim lebih banyak Mega!" Komandan berteriak.

"Kami tidak bisa, kami tidak punya cadangan!" Laksamana panik.

"Inti Utama diserang!" teriak Kapten.

Kapten semakin panik.

"Kami kehilangan sekte-" pemotongan komunikasi.

"Kaisar tidak akan menyenangkan." Kata Komandan, dengan suara rendah dan dalam.

…

Pintu diketuk. Komandan tahu apa yang terjadi.

Dia perlahan mulai berjalan ke pintu. Saat pintu dibuka paksa dari luar.

"Dengan perintah Kaisar." Kata Komandan Atas Antarplanet.

"Kamu diturunkan pangkatnya menjadi prajurit." Dia melanjutkan.

Komandan mulai panik bahkan lebih.

Kemudian Komandan Atas memecahkan kaca di pusat komando dan mengusir Komandan dengan paksa.

"Apakah ada orang lain di sini yang gagal ?!" dia berteriak.

Tidak ada yang berbicara.

“Bagus” katanya.

"Operasi ini sekarang di bawah manajemen Komandan Atas atas perintah Kaisar!"

...
