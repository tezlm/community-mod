**Part 7 – Failure once again!**

“Lets test this, *Sharded*” said the Upper Commander. 

“Send a T4 to the overgrowth and see if it will fail” he added.

“Yes Sir!” replied the Admiral.

…

“The T4 failed, we are slowly getting destroyed!” said the Captain.

Upper Commander thought deeply.

“We will stop them in NPC.” He said.

“But how?” asked the Admiral.

“I will go there with my ship.” He added.

“Get my Eclipse ready!” he shouted and left the command room.

Admiral didn’t know what type of ship an *Eclipse* was.

He quickly followed the Upper Commander.

He was waiting outside, there was nothing. It was just open wasteland.

Then a shadow blocked the sun. It was getting bigger and bigger every passing moment.

Admiral was shocked, it was in front of him. The Giga Destroyer. It was the biggest Star Ship he has ever seen. Packed with Cruiser destroying lasers and super massive cannons. He was speechless while he watched the Upper Commander walk to the elevator. He stood there while the Star Destroyer flew into the horizon.

…
