**Part 8 – Eclipse vs the Forces of Sharded**

-Upper Commander was slowly approaching NPC.

He got a message from the Admiral, “They have defeated all our forces.” He said.

“You are the only hope” he added.

“We see the NPC in the horizon.” Said the Pilot.

“Get the canons and lasers ready!” said the Upper Commander.

“Attack in 3, 2, 1, fire!” he shouted.

…

-Blast after blast, Eclipse slowly got closer to the core, but it was taking dangerous damage.

“We are nearly at their core!” Pilot said.

“But we don’t know how longer our cruiser can stand.” He added.

“Full power to the weapons!” Upper commander ordered.

“But sir, our shields are nearly down.” Captain said.

“I SAID ATTACK!” he ordered.

“Yes sir!” answered the Pilot.

-They reached the core but the cyclones weren’t giving up.

“Come on, come on!” said the Upper Commander.

“Shield down!” said the Pilot.

“Continue!” ordered the Upper Commander.

“Engine down, we are going to crash!” shouted the Captain.

“Continue to fire!” shouted the Upper Commander.

“WE MUST GO!” replied the Captain.

“Not until we destroy this core!” said the Upper Commander.

Captain and Pilot ran to the escape pod. They smashed the emergency button and watched the door close as the Upper Commander stayed there. Watching.

The pod launched.

“We should have saved the Upper Commander!” said the Captain.

“It’s too late for him.” Replied the Pilot and looked at the giant destroyer while it crashed to the land. Failing once again…

…


![image](https://user-images.githubusercontent.com/62565267/120976922-756e4d80-c77b-11eb-8828-f6305c3c9fe8.png)


