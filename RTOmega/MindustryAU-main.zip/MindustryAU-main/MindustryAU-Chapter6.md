**Part 6 – Fungal Pass-ed**

-Fungal Pass was small but it was the road to thorium and it was the only chance of Crux stopping Sharded for good.

“Sir, Sharded is progressing. It is funny that they use arcs and duos against us in Fungal Pass.” Said the Admiral.

Commander replied, “Send megas, polys, maces, daggers, crawler, fortress! Whatever we have! We must stop them!”

…	

“We are under attack!” said the Captain.

“One core down and we are failing to defend.” He added.

“We are sending more Megas!” Commander shouted.

“We can’t, we don’t have any spare!” Admiral panicked.

“Main Core under attack!” shouted the Captain.

Captain panicked even more.

“We are losing the secto-“ comms cut.

“The Emperor will not be please.” Said the Commander, with a low and deep voice.

…

The door got knocked. Commander knew what was about the happen.

He slowly started walking to the door. When the door got force opened from outside.

“With the order of the Emperor.” Said the InterPlanetary Upper Commander.

“You are demoted to solider.” He continued.

Commander started to panic even more.

Then the Upper commander broke the glass in the command center and threw Commander out with force. 

“Does anyone else here to fail?!” he shouted.

No one talked.

“Good” he said.

“This operation is now under the management of the Upper Commander by the order of the Emperor!”

...
