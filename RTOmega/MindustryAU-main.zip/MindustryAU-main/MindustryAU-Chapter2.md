**Part 2 - Chaos in the Craters**

2 Weeks have passed since the discovery of Sharded. 

Everything seemed calm, then it happened. 

Another core launched. However, it was from Frozen Forest. 

The Core landed on The Craters. 

The Commander gave the orders: “Find that core and destroy it!”

Captain replied: “We sent one of our latest and best units, the Zenith, a fully packed and armored battle ship with 2 rocket launchers.”

Admiral Continued: “There is no chance they get away this time.” Then he smiled and looked to the giant battle ship.

…

“Are you ready to attack Pilot?” asked the Captain.

“Yes sir, all system clear, we see the enemy base.” Replied the Pilot.

Commander smiled and said: “Fire at the scatter, if we destroy them, there is no chance they win this battle!”

Then pilot replied: “Si- - - There is a small prob- - -“

Then the communication cut off. 

Both Commander and the Admiral looked at each other, in shock. They realized that this was a bigger problem than they imagined. 

This was no small attack, it was a total planetary Invasion!
