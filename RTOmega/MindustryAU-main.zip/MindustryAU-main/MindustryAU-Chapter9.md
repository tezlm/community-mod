**Part 9 – Just a matter of Time**

Admiral was rushing through the corridor “Execute Emergency Protocol 01-49!” he shouted into the comms.

The alarms started to beep, everyone panicked.

“Evacuate to Planetary Launch Terminal! I repeat Evacuate to Planetary Launch Terminal!” he started shouting through the comms.

“Sir, Impact 0078 is down!” reported the Captain.

“A Squad, protect the PLT! B Squad, try to hold Sharded as much as you can in the Desolate Rift!” the Admiral shouted.

“We need time to evacuate!” he added and rushed to the last transport ship to PLR.

…

It was no less chaos in PLT, everyone was running and hoping they will be safe there.

“Try to protect with all your forces!” shouted the Admiral.

“Our forces are failing in Desolate Rift” said the Commander.

“Attack with the Zeniths!” shouted the Admiral.

“Uh, yeah, about that…” started the Commander.

“…”

“They destroyed them already…” he continued, while scratching his head.

“Fire with the Specters!?” asked the Admiral.

“yeah, they, they killed them too.” continued the Commander.

“I didn’t think I would do this… Unleash the Reign!” shouted the Admiral.

“And you never will because that was the first thing they destroyed.” Said the Commander.

“Do I have to do everything he-“ ,said the Admiral. The ground started shaking.

Admiral rushed outside and looked to the sky, a Nucleus Core was falling from the sky, ready to land.

“They are here.” murmured the Admiral.

…

“Toxopids, get ready.” Said the Commander.

“Attack in 5 ,4 ,3 ,2 ,1. Attack!” he shouted.

-One by one, all units of Crux got demolished by meltdowns, specters and foreshadows. Crux was losing many turrets and units but fail to stop Sharded.

“CORE UNDER ATTACK! CORE UNDER ATTACK!” shouted the Commander.

Admiral knew the only way is to escape, he quickly rushed to the InterPlanetary Accelerator,

Smashed the launch button and jumped inside.

The door closed, he heard the core explode, it was too late for everyone…

…

The Accelerator started counting,

“Launching in 10, 9”

The accelerator started taking damage.

“8, 7, 6, 5, 4”

Admiral panicked in an insane level.

“3, 2, 1, FIRE”

The accelerator launched the pod in space faster than sound, the entire Serpulo shook with its force, Admiral collapsed to the floor and the pod successfully docked to the Crux InterGalactic Space Station.

The doors opened and the Admiral standed up.

He walked to the command room, slowly.

…

“We lost Serpulo” he said.

The Emperor smiled.

“It’s a small price to pay for this intel.” Said the Emperor.

“Now we know that there are others.” He continued.

“Here, take this T6 and return to Tantros.” He added, while pointing one of the many Destroyers in the space fleet.

“Yes, my lord.” Said the Admiral and left the room.

“This battle has just begun.” Said the Emperor.

…

**Mindustry AU by RTOmega**

*Please give feedback and tell if I made any mistakes*
You can contribute by making a pull request.
