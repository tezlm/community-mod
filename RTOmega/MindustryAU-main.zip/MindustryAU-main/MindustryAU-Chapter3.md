**Part 3 – Shores UnderAtack**

“Sir, we have detected another launch, this time at the Craters.” Said the Admiral.

“Where did they launch to?” asked the Commander.

“It seems they went to Ruinous Shores.” Replied the Admiral.

Commander thought for a moment and said: “What if we attack in small group but faster?”

“That way, we can kill them with ease.” Said the Captain.

Captain opened the comms and gave the orders: “Attack from air and ground! Target the core and this time, path find to the weakest defence!”

“Yes Sir!” Said the Commando. Nodded the pilot.
…

A message came from the Commando: “Sir, they have lancers, I don’t know how much longer we can stand.”

“Don’t worry Commando! We have backup, we are sending the brand new, Fortress, it’s a fully armored walking tank with packed in hails.”

…


![image](https://user-images.githubusercontent.com/62565267/120976373-f37e2480-c77a-11eb-8cd1-17e47a37a98e.png)

“We lost the signal, the sector got captured.” Said the Admiral, with a crack in his voice.

-However, what they didn’t know was, this was just the start…
