**Part 5 - A Call for Reinforcements**

-Crux continued to fail to stop Sharded and now is getting attacked by it. 

With no chance of success, they try their best to protect their bases.

A message came from the Captain: “Our tactics are no match for their attack!”

Admiral sigh and replied: “How can they defeat us? Impossible! I order you to go and stop them in Salt Flats and Extraction Outpost!”

Captain didn’t even answer. He knew they would fail. They needed better guns, bigger units.

Commander knew what he had to do.

He walked to the comms, very slowly, entered the code and started sending a message.

“My Lord…” He said.

“Our forces are ineffective against Sharded.” He continued.

“We need reinforcements. We need  -“ He stopped for a few seconds.

“T5s” he added.

“Very well,” said the Emperor. 

“But I don’t want any more failures or you will be replaced.” he added.

…
