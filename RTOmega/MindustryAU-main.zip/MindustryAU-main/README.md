# MindustryAU
A FanFic/Lore about Mindustry Campaign, from the perspective of Crux.

This FanFic/Lore is writen and edited by **RTOmega.**

# Contributors:
- WilloIzCitron#8360 [ID translation] (https://github.com/WilloIzCitron/MindustryAU-ID)
-
-
