**Part 4 – Mountains and Islands**

-After several attempts, Crux still continued to fail at defeating Sharded.

“Sir, it seems that they have launched to 2 sectors at the same time.” Said the Admiral.

“What sectors?” asked the Commander.

“Stained Mountains and Windswept Islands sir.” Said the Admiral.

“This is becoming a bigger problem every following day, send our best units!” said the Commander.

“Behold, our new and powerful units: Navals” said the professor while entering the command center room.

“These new units have powerful missiles and swim in water.” Continued the professor.

Captain entered the room and started to talk, “Sir, our mechanics built a unit that will solve our problems in Stained Mountains!”

“What is it?” asked the professor.

“It’s the one and only, *Scepter*, it’s a walking battle station, 50 times more powerful then Fortress. Fully packed with a giant blaster and 2 mega cannons, this unit can destroy anything on its way.”

“I don’t want any failure this time! We must win this war, before its too late.” Said the Commander.

…

“They have defeated most of our naval units” said the captain.

“I knew they would! For some reason, all of your units are useless professor!” shouted the Commander.

Professor took the comms, “Release the bigger naval, I repeat, release the bigger naval!”

Admiral and Commander looked at each other.

“Professor, we were about to kill their core, but then a lancer killed our last naval!” shouted Captain.

Professor sighed, he knew he need to do better.

…

“Is our surprise attack ready?” asked the Commander.

“Yes sir!” replied the Captain.

“Unleash the *Scepter*!” ordered the Commander. 

“We are destroying their lancers sir!” said the captain.

“Their Ripples are firing, but we are nearly at their core.” He continued.

Commander started to hesitate.

“5 hits” said the Captain and started counting.

“4, 3, 2, 1” …

Comms cut off.

Admiral looked at the Commander.

They both knew they failed.

-But it will just get worse from here.
