***Mindustry AU*** - The story of 2

Part 1 - Crash land 

It was a peaceful day, Crux was nearly in complete control of Serpulo. 

Then, a small object fell...

“What was that? A meteor perhaps?” Asked the upper Commander of Crux.

“We don’t know, it went too fast for our radars.” said the Admiral.

“Send a small squad to Ground Zero and check what it is.” said the Commander.

-Little did they know, it was the core of Sharded.

A few days passed, then the Commander asked, “What was the object that fall?”

“Well...” Admiral said.

“None of our units returned, they are possible all killed or captured.” told the Admiral.

...

A week passed, then an object got launched from Ground Zero to Frozen Forest.

“What happened?” Asked the Commander.

Admiral replied, “An unknown object launched from Ground Zero to Frozen forest sir.”

The Commander stopped for a few moments and then realized, “THATS NOT AN OBJECT! THAT’S A CORE!”

Admiral shouted in panic: “But that’s impossible!

There aren’t any known other civilization that can make cores!”

“We know one now! Note it as S, with yellow, in the archive Captain. Name it Shard!”

“But sir” said the Admiral, “Shard is a type of core we have.”

“Then make it Shard-ed”, shouted the Commander and stared to the window.

-It has begun...
